require.config({ paths: { 'vs': 'https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.33.0/min/vs' } });

let editor;

// Initialize Monaco Editor
require(['vs/editor/editor.main'], function () {
    editor = monaco.editor.create(document.getElementById('editor-container'), {
        value: [
            '<!DOCTYPE html>',
            '<html lang="en">',
            '<head>',
            '    <meta charset="UTF-8">',
            '    <meta name="viewport" content="width=device-width, initial-scale=1.0">',
            '    <title>Links and Table Example</title>',
            '    <style>',
            '        body {',
            '            font-family: Arial, sans-serif;',
            '            background-color: #f9f9f9;',
            '            color: #333;',
            '            margin: 0;',
            '            padding: 20px;',
            '            text-align: center;',
            '        }',
            '        h1 {',
            '            color: #4a90e2;',
            '            margin-bottom: 20px;',
            '        }',
            '        h2 {',
            '            color: #333;',
            '            margin-top: 30px;',
            '            margin-bottom: 10px;',
            '        }',
            '        p {',
            '            font-size: 1.1em;',
            '            margin-bottom: 20px;',
            '        }',
            '        ul {',
            '            list-style-type: none;', // Remove default bullets
            '            padding: 0;',
            '            margin: 20px 0;',
            '        }',
            '        li {',
            '            margin: 10px 0;',
            '        }',
            '        a {',
            '            text-decoration: none;',
            '            color: #4a90e2;', // Link color
            '            font-weight: bold;',
            '            transition: color 0.3s;',
            '        }',
            '        a:hover {',
            '            color: #333;', // Change color on hover
            '        }',
            '        table {',
            '            width: 100%;',
            '            border-collapse: collapse;',
            '            margin-top: 20px;',
            '        }',
            '        th, td {',
            '            border: 1px solid #ccc;',
            '            padding: 10px;',
            '            text-align: left;',
            '        }',
            '        th {',
            '            background-color: #4a90e2;',
            '            color: white;',
            '        }',
            '        tr:nth-child(even) {',
            '            background-color: #f2f2f2;', // Zebra striping
            '        }',
            '    </style>',
            '</head>',
            '<body>',
            '    <h1>Links and Table Example</h1>',
            '    <p>Here are some links:</p>',
            '    <ul>',
            '        <li><a href="https://www.google.com" target="_blank">Google</a></li>',
            '        <li><a href="https://www.wikipedia.org" target="_blank">Wikipedia</a></li>',
            '        <li><a href="https://www.github.com" target="_blank">GitHub</a></li>',
            '    </ul>',
            '    <h2>Sample Table</h2>',
            '    <table>',
            '        <thead>',
            '            <tr>',
            '                <th>Name</th>',
            '                <th>Age</th>',
            '                <th>Country</th>',
            '            </tr>',
            '        </thead>',
            '        <tbody>',
            '            <tr>',
            '                <td>Alice</td>',
            '                <td>30</td>',
            '                <td>USA</td>',
            '            </tr>',
            '            <tr>',
            '                <td>Bob</td>',
            '                <td>25</td>',
            '                <td>Canada</td>',
            '            </tr>',
            '            <tr>',
            '                <td>Charlie</td>',
            '                <td>35</td>',
            '                <td>UK</td>',
            '            </tr>',
            '        </tbody>',
            '    </table>',
            '</body>',
            '</html>'
        ].join('\n'),
        language: 'html',
        theme: 'vs-dark'
    });
});

// Run the user's code
function runCode() {
    const outputDiv = document.getElementById("threejs-output");
    outputDiv.innerHTML = ''; // Clear previous output

    // Clear the previous output
    const existingFrame = outputDiv.querySelector('iframe');
    if (existingFrame) {
        existingFrame.remove();
    }

    // Create a new iframe for the user HTML
    const iframe = document.createElement('iframe');
    iframe.style.width = '100%';
    iframe.style.height = '100%';
    iframe.style.border = 'none';
    outputDiv.appendChild(iframe);

    const userCode = editor.getValue();
    const iframeDoc = iframe.contentWindow.document;

    try {
        // Write user code to the iframe
        iframeDoc.open();
        iframeDoc.write(userCode);
        iframeDoc.close();
    } catch (error) {
        console.error('Error in user code:', error);
        outputDiv.innerHTML = 'Error in user code: ' + error.message;
    }
}
