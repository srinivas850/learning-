 // Scene, Camera, Renderer setup
 const scene = new THREE.Scene();
 const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
 const renderer = new THREE.WebGLRenderer();
 renderer.setSize(window.innerWidth, window.innerHeight);
 document.body.appendChild(renderer.domElement);

 // Function to add stars to the scene
 function addStars() {
   const starGeometry = new THREE.BufferGeometry();
   const starMaterial = new THREE.PointsMaterial({ color: 0xffffff });

   const starVertices = [];
   for (let i = 0; i < 300; i++) {  // Reduced number of stars
     const x = THREE.MathUtils.randFloatSpread(1000);
     const y = THREE.MathUtils.randFloatSpread(1000);
     const z = THREE.MathUtils.randFloatSpread(1000);
     starVertices.push(x, y, z);
   }

   starGeometry.setAttribute('position', new THREE.Float32BufferAttribute(starVertices, 3));
   const stars = new THREE.Points(starGeometry, starMaterial);
   scene.add(stars);
 }
 addStars();

 // Create sun with a fire-like effect using ShaderMaterial
 const sunGeometry = new THREE.SphereGeometry(20, 32, 32);
 
 const sunMaterial = new THREE.ShaderMaterial({
   uniforms: {
     time: { value: 0 },
     emissiveColor: { value: new THREE.Color(1.0, 1.0, 0.0) } // Yellow color
   },
   vertexShader: `
     varying vec2 vUv;
     varying vec3 vNormal;
     void main() {
       vUv = uv;
       vNormal = normal;
       vec3 transformed = position + normal * sin(position.y * 5.0 + time) * 0.5;
       gl_Position = projectionMatrix * modelViewMatrix * vec4(transformed, 1.0);
     }
   `,
   fragmentShader: `
     uniform float time;
     uniform vec3 emissiveColor;
     varying vec2 vUv;
     varying vec3 vNormal;

     void main() {
       float flicker = sin(vUv.x * 10.0 + time) * 0.1;
       vec3 color = emissiveColor * (1.0 + flicker);
       gl_FragColor = vec4(color, 1.0);
     }
     `,
     transparent: true,
   });

   const sun = new THREE.Mesh(sunGeometry, sunMaterial);
   scene.add(sun);

 // Lighting for realism
 const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
 scene.add(ambientLight);

 const pointLight = new THREE.PointLight(0xffffff, 1);
 pointLight.position.set(0, 0, 0);  // At the center (sun)
 scene.add(pointLight);

 camera.position.set(30, 20, 10);  // Camera positioned higher and slightly back
 camera.lookAt(0, 0, 0);  // Make the camera look at the sun (center)

 // Planet details (each planet has a different color)
 const planets = [
   { name: 'Java', size: 2.0, distance: 8, color: 0xff5733, url: 'java.html' },       // Red planet
   { name: 'Python', size: 2.3, distance: 12, color: 0x33ff57, url: 'python.html' },   // Green planet
   { name: 'JavaScript', size: 2.4, distance: 16, color: 0x3357ff, url: 'javascript.html' }, // Blue planet
   { name: 'C++', size: 2.4, distance: 20, color: 0xff33a5, url: 'cpp.html' },         // Pink planet
   { name: 'C#', size: 2.4, distance: 24, color: 0xffa533, url: 'csharp.html' },       // Orange planet
   { name: 'Go', size: 2.4, distance: 28, color: 0x57ff33, url: 'go.html' },           // Light green planet
   { name: 'Ruby', size: 1.4, distance: 32, color: 0xff3357, url: 'ruby.html' },       // Purple planet
   { name: 'PHP', size: 1.5, distance: 36, color: 0x33a5ff, url: 'php.html' },         // Light blue planet
   { name: 'Swift', size: 1.6, distance: 38, color: 0xa533ff, url: 'swift.html' }      // Violet planet
 ];

 const planetMeshes = [];

 // Create planets with color and labels
 planets.forEach(planet => {
   const geometry = new THREE.SphereGeometry(planet.size, 40, 40);
   const material = new THREE.MeshBasicMaterial({ color: planet.color });
   const mesh = new THREE.Mesh(geometry, material);
   
   mesh.position.x = planet.distance;
   mesh.userData = { url: planet.url, name: planet.name }; // Store URL and name for redirection and labeling
   scene.add(mesh);
   planetMeshes.push(mesh);

   // Add label (language name) above the planet
   const labelDiv = document.createElement('div');
   labelDiv.style.position = 'absolute';
   labelDiv.style.color = 'white';
   labelDiv.innerHTML = planet.name;
   labelDiv.style.fontSize = '10px';
   document.body.appendChild(labelDiv);

   // Update label position in the animation loop
   mesh.userData.labelDiv = labelDiv;
 });

 // Create orbital lines for each planet
 planets.forEach(planet => {
   const orbitGeometry = new THREE.RingGeometry(planet.distance - 0.05, planet.distance + 0.05, 64);
   const orbitMaterial = new THREE.MeshBasicMaterial({ color: 0xffffff, side: THREE.DoubleSide });
   const orbit = new THREE.Mesh(orbitGeometry, orbitMaterial);
   orbit.rotation.x = Math.PI / 2; // Align the ring horizontally
   scene.add(orbit);
 });

 // Animation loop
 function animate() {
   requestAnimationFrame(animate);

   // Rotate each planet and add orbit
   planetMeshes.forEach((planetMesh, index) => {
     planetMesh.rotation.y += 0.01; // Spin the planet

     // Circular orbit logic (simple, not to scale)
     planetMesh.position.x = Math.cos(Date.now() * 0.001 + index) * planets[index].distance;
     planetMesh.position.z = Math.sin(Date.now() * 0.001 + index) * planets[index].distance;

     // Update label position based on planet position
     const screenPosition = planetMesh.position.clone();
     screenPosition.project(camera);

     const labelDiv = planetMesh.userData.labelDiv;
     const x = (screenPosition.x * 0.5 + 0.5) * window.innerWidth;
     const y = -(screenPosition.y * 0.5 - 0.5) * window.innerHeight;
     labelDiv.style.left = `${x}px`;
     labelDiv.style.top = `${y}px`;
   });

   // Update sun material's time uniform
   sunMaterial.uniforms.time.value += 0.05; // Adjust speed of flicker

   renderer.render(scene, camera);
 }

 // Handle click events on planets
 document.addEventListener('click', (event) => {
   const mouse = new THREE.Vector2(
     (event.clientX / window.innerWidth) * 2 - 1,
     -(event.clientY / window.innerHeight) * 2 + 1
   );

   const raycaster = new THREE.Raycaster();
   raycaster.setFromCamera(mouse, camera);

   const intersects = raycaster.intersectObjects(planetMeshes);

   if (intersects.length > 0) {
     const planet = intersects[0].object.userData;
     window.location.href = planet.url; // Redirect to the corresponding language page
   }
 });
   // Rotate each planet and add slower orbit
   planetMeshes.forEach((planetMesh, index) => {
     planetMesh.rotation.y += 0.005; // Slower spin for planets

     // Slower circular orbit logic
     planetMesh.position.x = Math.cos(Date.now() * 0.0003 + index) * planets[index].distance;
     planetMesh.position.z = Math.sin(Date.now() * 0.0003 + index) * planets[index].distance;

     // Update label position based on planet position
     const screenPosition = planetMesh.position.clone();
     screenPosition.project(camera);

     const labelDiv = planetMesh.userData.labelDiv;
     const x = (screenPosition.x * 0.5 + 0.5) * window.innerWidth;
     const y = -(screenPosition.y * 0.5 - 0.5) * window.innerHeight;
     labelDiv.style.left = `${x}px`;
     labelDiv.style.top = `${y}px`;
   });

 animate(); // Start the animation loop

 // Handle window resize
 window.addEventListener('resize', () => {
   camera.aspect = window.innerWidth / window.innerHeight;
   camera.updateProjectionMatrix();
   renderer.setSize(window.innerWidth, window.innerHeight);
 });
 