require.config({ paths: { 'vs': 'https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.33.0/min/vs' } });

let editor;

// Initialize Monaco Editor
require(['vs/editor/editor.main'], function () {
    editor = monaco.editor.create(document.getElementById('editor-container'), {
        value: [
            '<!DOCTYPE html>',
            '<html lang="en">',
            '<head>',
            '    <meta charset="UTF-8">',
            '    <meta name="viewport" content="width=device-width, initial-scale=1.0">',
            '    <title>CSS Padding Example</title>',
            '    <style>',
            '        body {',
            '            font-family: Arial, sans-serif;',
            '            background-color: #f0f0f0;',
            '            color: #333;',
            '            margin: 0;',
            '            padding: 20px;',
            '        }',
            '        .box {',
            '            width: 200px;',
            '            height: 100px;',
            '            background-color: #4a90e2;',
            '            color: white;',
            '            padding: 40px 20px;',  // Top/bottom and left/right padding
            '            text-align: center;',
            '            line-height: 60px;', // Adjusted to center text vertically with padding
            '            border-radius: 8px;',
            '        }',
            '    </style>',
            '</head>',
            '<body>',
            '    <h1>CSS Padding Example</h1>',
            '    <div class="box">Box with Padding</div>',
            '    <p>The box above has top and bottom padding of 40px and left and right padding of 20px.</p>',
            '</body>',
            '</html>'
        ].join('\n'),
        language: 'html',
        theme: 'vs-dark'
    });
});

// Run the user's code
function runCode() {
    const outputDiv = document.getElementById("threejs-output");
    outputDiv.innerHTML = ''; // Clear previous output

    // Clear the previous output
    const existingFrame = outputDiv.querySelector('iframe');
    if (existingFrame) {
        existingFrame.remove();
    }

    // Create a new iframe for the user HTML
    const iframe = document.createElement('iframe');
    iframe.style.width = '100%';
    iframe.style.height = '100%';
    iframe.style.border = 'none';
    outputDiv.appendChild(iframe);

    const userCode = editor.getValue();
    const iframeDoc = iframe.contentWindow.document;

    try {
        // Write user code to the iframe
        iframeDoc.open();
        iframeDoc.write(userCode);
        iframeDoc.close();
    } catch (error) {
        console.error('Error in user code:', error);
        outputDiv.innerHTML = 'Error in user code: ' + error.message;
    }
}
