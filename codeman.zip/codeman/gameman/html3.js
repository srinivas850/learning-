require.config({ paths: { 'vs': 'https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.33.0/min/vs' } });

let editor;

// Initialize Monaco Editor
require(['vs/editor/editor.main'], function () {
    editor = monaco.editor.create(document.getElementById('editor-container'), {
        value: [
            '<!DOCTYPE html>',
            '<html lang="en">',
            '<head>',
            '    <meta charset="UTF-8">',
            '    <meta name="viewport" content="width=device-width, initial-scale=1.0">',
            '    <title>Image Example</title>',
            '    <style>',
            '        body {',
            '            font-family: Arial, sans-serif;',
            '            background-color: #f4f4f4;',
            '            color: #333;',
            '            margin: 0;',
            '            padding: 20px;',
            '            text-align: center;',
            '        }',
            '        h1 {',
            '            color: #4a90e2;',
            '        }',
            '        img {',
            '            border: 2px solid #4a90e2;',
            '            border-radius: 8px;',
            '            margin: 20px 0;',
            '            max-width: 100%;', // Make the image responsive
            '            height: auto;',
            '        }',
            '        p {',
            '            font-size: 1.2em;',
            '            margin: 10px 0;',
            '        }',
            '    </style>',
            '</head>',
            '<body>',
            '    <h1>Image Example</h1>',
            '    <img src="https://via.placeholder.com/300" alt="Placeholder Image">',
            '    <p>This is a placeholder image. You can replace the source with any image URL.</p>',
            '</body>',
            '</html>'
        ].join('\n'),
        language: 'html',
        theme: 'vs-dark'
    });
});

// Run the user's code
function runCode() {
    const outputDiv = document.getElementById("threejs-output");
    outputDiv.innerHTML = ''; // Clear previous output

    // Clear the previous output
    const existingFrame = outputDiv.querySelector('iframe');
    if (existingFrame) {
        existingFrame.remove();
    }

    // Create a new iframe for the user HTML
    const iframe = document.createElement('iframe');
    iframe.style.width = '100%';
    iframe.style.height = '100%';
    iframe.style.border = 'none';
    outputDiv.appendChild(iframe);

    const userCode = editor.getValue();
    const iframeDoc = iframe.contentWindow.document;

    try {
        // Write user code to the iframe
        iframeDoc.open();
        iframeDoc.write(userCode);
        iframeDoc.close();
    } catch (error) {
        console.error('Error in user code:', error);
        outputDiv.innerHTML = 'Error in user code: ' + error.message;
    }
}
