require.config({ paths: { 'vs': 'https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.33.0/min/vs' } });

let editor;

// Initialize Monaco Editor
require(['vs/editor/editor.main'], function () {
    editor = monaco.editor.create(document.getElementById('editor-container'), {
        value: [
            '<!DOCTYPE html>',
            '<html lang="en">',
            '<head>',
            '    <meta charset="UTF-8">',
            '    <meta name="viewport" content="width=device-width, initial-scale=1.0">',
            '    <title>Form Example</title>',
            '    <style>',
            '        body {',
            '            font-family: Arial, sans-serif;',
            '            background-color: #f4f4f4;',
            '            color: #333;',
            '            margin: 0;',
            '            padding: 20px;',
            '            text-align: center;',
            '        }',
            '        h1 {',
            '            color: #4a90e2;',
            '        }',
            '        form {',
            '            background-color: #fff;',
            '            padding: 20px;',
            '            border-radius: 8px;',
            '            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);',
            '            max-width: 400px;',
            '            margin: 0 auto;',
            '        }',
            '        label {',
            '            display: block;',
            '            margin: 10px 0 5px;',
            '        }',
            '        input[type="text"], input[type="email"] {',
            '            width: calc(100% - 22px);', // Account for padding and borders
            '            padding: 10px;',
            '            border: 1px solid #ccc;',
            '            border-radius: 4px;',
            '            margin-bottom: 15px;',
            '        }',
            '        input[type="submit"] {',
            '            background-color: #4a90e2;',
            '            color: white;',
            '            border: none;',
            '            padding: 10px 15px;',
            '            border-radius: 4px;',
            '            cursor: pointer;',
            '        }',
            '        input[type="submit"]:hover {',
            '            background-color: #357ABD;',
            '        }',
            '    </style>',
            '</head>',
            '<body>',
            '    <h1>Form Example</h1>',
            '    <form action="/submit" method="post">',
            '        <label for="name">Name:</label>',
            '        <input type="text" id="name" name="name" required>',
            '        <label for="email">Email:</label>',
            '        <input type="email" id="email" name="email" required>',
            '        <input type="submit" value="Submit">',
            '    </form>',
            '</body>',
            '</html>'
        ].join('\n'),
        language: 'html',
        theme: 'vs-dark'
    });
});

// Run the user's code
function runCode() {
    const outputDiv = document.getElementById("threejs-output");
    outputDiv.innerHTML = ''; // Clear previous output

    // Clear the previous output
    const existingFrame = outputDiv.querySelector('iframe');
    if (existingFrame) {
        existingFrame.remove();
    }

    // Create a new iframe for the user HTML
    const iframe = document.createElement('iframe');
    iframe.style.width = '100%';
    iframe.style.height = '100%';
    iframe.style.border = 'none';
    outputDiv.appendChild(iframe);

    const userCode = editor.getValue();
    const iframeDoc = iframe.contentWindow.document;

    try {
        // Write user code to the iframe
        iframeDoc.open();
        iframeDoc.write(userCode);
        iframeDoc.close();
    } catch (error) {
        console.error('Error in user code:', error);
        outputDiv.innerHTML = 'Error in user code: ' + error.message;
    }
}
