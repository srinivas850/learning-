// server.js
const express = require('express');
const http = require('http');
const socketIo = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

app.use(express.static('public'));

let gameRooms = {};

io.on('connection', (socket) => {
    console.log('New player connected:', socket.id);

    socket.on('joinGame', ({ roomId }) => {
        socket.join(roomId);
        if (!gameRooms[roomId]) {
            gameRooms[roomId] = { players: [] };
        }
        gameRooms[roomId].players.push(socket.id);

        if (gameRooms[roomId].players.length === 2) {
            io.to(roomId).emit('startGame', { message: 'Game starts now! Start coding!' });
        }
    });

    socket.on('codeSubmission', ({ roomId, code }) => {
        // Simple check (simulation): code length or other validation could be added
        const playerIsWinner = Math.random() > 0.5; // Random winner for demo
        if (playerIsWinner) {
            io.to(roomId).emit('gameOver', { winner: socket.id });
        }
    });

    socket.on('disconnect', () => {
        for (let roomId in gameRooms) {
            gameRooms[roomId].players = gameRooms[roomId].players.filter(id => id !== socket.id);
            if (gameRooms[roomId].players.length === 0) delete gameRooms[roomId];
        }
    });
});

server.listen(3000, () => console.log('Server running on http://localhost:3000'));
