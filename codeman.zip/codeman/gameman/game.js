const socket = io();

document.getElementById('joinGame').onclick = () => {
    const roomId = document.getElementById('roomId').value;
    socket.emit('joinGame', { roomId });
    document.getElementById('codingArea').style.display = 'block';
};

socket.on('startGame', (data) => {
    document.getElementById('status').innerText = data.message;
});

document.getElementById('submitCode').onclick = () => {
    const roomId = document.getElementById('roomId').value;
    const code = document.getElementById('codeInput').value;
    socket.emit('codeSubmission', { roomId, code });
};

socket.on('gameOver', (data) => {
    document.getElementById('status').innerText = data.winner === socket.id ? "You win!" : "You lose!";
});
const joinGameButton = document.getElementById('joinGame');
const codingArea = document.getElementById('codingArea');

joinGameButton.addEventListener('click', () => {
    const roomId = document.getElementById('roomId').value;
    if (roomId) {
        // Simulate a successful room joining with an animation
        codingArea.style.display = 'block';
        codingArea.classList.add('fade-in');
        document.getElementById('roomId').value = '';
    }
});

// Add CSS for fade-in animation
const styleSheet = document.createElement("game");
styleSheet.type = "text/css";
styleSheet.innerHTML = `
    @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
    }
    .fade-in {
        animation: fadeIn 0.5s ease;
    }
`;
document.head.appendChild(styleSheet);
