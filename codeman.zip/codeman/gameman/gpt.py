from flask import Flask, request, jsonify, render_template
import openai

app = Flask(__name__)

# Set your OpenAI API key here (ensure this is kept secret in production)
openai.api_key = 'sk-pYxwK-qRnTp1sstdmzc8TTeo5v_Hp-rpMyHyXx_wowT3BlbkFJNoS1yVT2qmFzuhuJyLMovdIOMDEW3oC5M93JSrCFIA'  # Replace with your actual API key

@app.route('/')
def index():
    # Render the HTML file for the chat interface
    return render_template('gpt.html')

@app.route('/api', methods=['POST'])
def chat_api():
    # Get the message from the request
    data = request.get_json()
    user_message = data.get('message', '')

    if not user_message:
        return jsonify({'response': 'No message provided.'}), 400

    try:
        # Use OpenAI API to get a response
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": user_message}
            ]
        )
        # Extract the response text
        bot_response = response['choices'][0]['message']['content'].strip()
        return jsonify({'response': bot_response})
    except Exception as e:
        # Return an error if the API request fails with more details
        return jsonify({'response': f'Error: Unable to process your request. {str(e)}'}), 500

if __name__ == '__main__':
    app.run(debug=True)  # Run the app in debug mode
