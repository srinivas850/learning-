const express = require("express");
const mongoose = require("mongoose");
const path = require("path");
const bodyParser = require("body-parser");
const cookieParser = require("cookie-parser");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");
require("dotenv").config();
const app = express();
const port = 8854;
mongoose.connect(process.env.MONGODB_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => {
    console.log("Connected to MongoDB");
}).catch((error) => {
    console.error("Error connecting to MongoDB:", error);
});

// Define a User schema and model
const userSchema = new mongoose.Schema({
    firstName: String,
    lastName: String,
    email: { type: String, unique: true },
    password: String,
    mobile: String,
    profile: {
        phone: String,
        interests: String,
        bio: String
    }
});
const User = mongoose.model("User", userSchema);

// Middleware for parsing JSON and URL-encoded data
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, "gameman")));

// JWT Authentication Middleware
const authenticateToken = (req, res, next) => {
    const token = req.headers.authorization && req.headers.authorization.split(" ")[1];
    if (!token) return res.status(401).json({ message: "Access denied" });

    jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
        if (err) return res.status(403).json({ message: "Invalid token" });
        req.userId = user.userId; // Set userId for later use
        next();
    });
};

// Routes

// Registration route
app.post("/submit-registration", async (req, res) => {
    const { firstName, lastName, email, password, mobile } = req.body;

    try {
        const userExists = await User.findOne({ email });
        if (userExists) {
            return res.status(400).json({ message: "User already registered. Please login." });
        } else {
            const hashedPassword = await bcrypt.hash(password, 10);
            const newUser = new User({ firstName, lastName, email, password: hashedPassword, mobile });
            await newUser.save();
            return res.status(200).json({ message: "Registration successful." });
        }
    } catch (error) {
        console.error("Error saving user data:", error);
        res.status(500).json({ message: "Error saving user data." });
    }
});

// Sign-In route
app.post("/signin", async (req, res) => {
    const { email, password } = req.body;

    try {
        const user = await User.findOne({ email });
        if (!user || !(await bcrypt.compare(password, user.password))) {
            return res.status(401).json({ message: "Invalid email or password." });
        }

        const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, { expiresIn: '1h' });
        return res.status(200).json({ message: "Sign-in successful.", token });
    } catch (error) {
        console.error("Error during sign-in:", error);
        return res.status(500).json({ message: "Error during sign-in." });
    }
});

// Profile route (Protected)
app.get("/profile", authenticateToken, async (req, res) => {
    try {
        const user = await User.findById(req.userId).select("firstName lastName email profile");
        if (!user) return res.status(404).send("User not found");

        res.json({ user });
    } catch (error) {
        console.error("Error fetching profile:", error);
        res.status(500).json({ message: "Error retrieving profile data" });
    }
});

// Profile update route (Protected)
app.post("/profile", authenticateToken, async (req, res) => {
    const { phone, interests, bio } = req.body;

    try {
        const user = await User.findByIdAndUpdate(
            req.userId,
            { profile: { phone, interests, bio } },
            { new: true }
        );
        res.json({ message: "Profile updated successfully", user });
    } catch (error) {
        console.error("Error updating profile:", error);
        res.status(500).json({ message: "Error updating profile" });
    }
});

// Static routes for additional pages
app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "gameman", "index.html"));
});
app.get("/search", (req, res) => {
    res.sendFile(path.join(__dirname, "gameman", "search.html"));
});
app.get("/course", (req, res) => {
    res.sendFile(path.join(__dirname, "gameman", "courses.html"));
});
app.get("/plans", (req, res) => {
    res.sendFile(path.join(__dirname, "gameman", "plans.html"));
});

// Logout Route
app.post("/logout", (req, res) => {
    res.json({ message: "Logged out successfully" });
});
// 404 handler for undefined routes
app.use((req, res) => {
    res.status(404).send("Page not found");
});
// Start the server
app.listen(port, () => {
    console.log(`Server started on http://localhost:${port}`);
});