// routes/auth.js
const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const User = require('./models/User'); // Adjust the path as necessary
const router = express.Router();

// Registration route
router.post('/submit-registration', async (req, res) => {
    const { firstName, lastName, email, password, mobile } = req.body;

    try {
        const userExists = await User.findOne({ email });
        if (userExists) {
            return res.status(400).json({ message: "User already registered. Please login." });
        } else {
            const hashedPassword = await bcrypt.hash(password, 10);
            const newUser = new User({ firstName, lastName, email, password: hashedPassword, mobile });
            await newUser.save();
            return res.status(200).json({ message: "Registration successful." });
        }
    } catch (error) {
        console.error("Error saving user data:", error);
        res.status(500).json({ message: "Error saving user data." });
    }
});

// Sign-In route
router.post('/signin', async (req, res) => {
    const { email, password } = req.body;

    try {
        const user = await User.findOne({ email });
        if (!user || !(await bcrypt.compare(password, user.password))) {
            return res.status(401).json({ message: "Invalid email or password." });
        }

        const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, { expiresIn: '1h' });
        return res.status(200).json({ message: "Sign-in successful.", token });
    } catch (error) {
        console.error("Error during sign-in:", error);
        return res.status(500).json({ message: "Error during sign-in." });
    }
});

module.exports = router;
